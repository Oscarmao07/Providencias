## Proceso de carga de la base de datos desde imágenes de PDF

Este aplicativo también incluye un proceso para cargar la base de datos de MongoDB utilizando imágenes de PDF. El objetivo de este proceso es extraer el texto de los archivos PDF y almacenarlo en la base de datos para su posterior consulta.

### Requisitos

- Python 3.x instalado en tu sistema.
- Las siguientes dependencias Python: `pymongo`, `PyPDF2`, `fitz`, `pytesseract`. Puedes instalarlas ejecutando el siguiente comando: `pip install pymongo PyPDF2 PyMuPDF pytesseract`.

### Instrucciones

1. Asegúrate de tener una conexión MongoDB configurada:
# Configuración de conexión MongoDB
MONGO_HOST = "localhost"
MONGO_PUERTO = "27017"
MONGO_TIMEOUT = 1000
2. Crea una carpeta principal que contenga los archivos PDF de los cuales deseas extraer el texto. Por ejemplo, puedes crear una carpeta llamada `DatasetTotal` y colocar allí los archivos PDF, esta es la ruta que lee el programa D:/Maestria/Big Data/Proyecto final/DatasetTotal
3. Abre el archivo `carguepdf.py`.
4. Ejecuta el archivo `carga_base_datos.py`. Este proceso recorrerá la carpeta principal y extraerá el texto de cada archivo PDF utilizando OCR (Optical Character Recognition).
5. El texto extraído de cada PDF se almacenará en la base de datos MongoDB en la colección `providenciasf`.

**Nota**: Este proceso puede tardar dependiendo de la cantidad de archivos PDF y el tamaño de las imágenes. Asegúrate de tener suficiente espacio en disco.

## Autor

Oscar Mauricio Carvajal Suárez

