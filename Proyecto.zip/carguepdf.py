import os
import pymongo
from PyPDF2 import PdfFileReader
import fitz
import pytesseract
from datetime import datetime

# Ruta de la carpeta principal que contiene los PDF
ruta_carpeta_proyectos = "D:/Maestria/Big Data/Proyecto final/DatasetTotal"

# Configuración de conexión MongoDB
MONGO_HOST = "localhost"
MONGO_PUERTO = "27017"
MONGO_TIMEOUT = 1000
MONGO_URI = "mongodb://"+MONGO_HOST+":"+MONGO_PUERTO+"/"

# Conexión a MongoDB
try:
    cliente = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=MONGO_TIMEOUT)
    cliente.server_info()
    print("Conexión a MongoDB exitosa")
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
except pymongo.errors.ServerSelectionTimeoutError as errorTiempo:
    print("Tiempo excedido " + str(errorTiempo))
except pymongo.errors.ConnectionFailure as errorConexion:
    print("Fallo al conectarse a MongoDB " + str(errorConexion))

# Función para extraer el texto de una imagen utilizando OCR (pytesseract)
def extraer_texto_imagen(ruta_imagen):
    texto = pytesseract.image_to_string(ruta_imagen)
    return texto

# Función para extraer el texto de un PDF utilizando PyMuPDF y OCR  
def extraer_texto_pdf(ruta_pdf):
    texto = ""
    with fitz.open(ruta_pdf) as doc:
        for pagina in doc:
            imagenes = pagina.get_images(full=True)
            for imagen in imagenes:
                xref = imagen[0]
                base_image = doc.extract_image(xref)
                ruta_imagen = f"temp_image_{xref}.png"
                try:
                    with open(ruta_imagen, "wb") as archivo_imagen:
                        archivo_imagen.write(base_image["image"])
                    texto_imagen = extraer_texto_imagen(ruta_imagen)
                    texto += texto_imagen + "\n"
                except Exception as e:
                    print(f"Error al procesar la imagen en la página {pagina.number}: {str(e)}")
                finally:
                    os.remove(ruta_imagen)
    return texto


# Recorrido de las carpetas por año
for carpeta_ano in os.listdir(ruta_carpeta_proyectos):
    ruta_carpeta_ano = os.path.join(ruta_carpeta_proyectos, carpeta_ano)
    if os.path.isdir(ruta_carpeta_ano):
        # Recorrido de los PDF en la carpeta actual
        for archivo_pdf in os.listdir(ruta_carpeta_ano):
            if archivo_pdf.endswith(".pdf"):
                ruta_pdf = os.path.join(ruta_carpeta_ano, archivo_pdf)
                # Extracción del texto del PDF
                texto_pdf = extraer_texto_pdf(ruta_pdf)

                # Obtención de los detalles del PDF
                nombre_pdf = archivo_pdf
                tipo_pdf = ""
                if nombre_pdf.startswith("C"):
                    tipo_pdf = "Constitucionalidad"
                elif nombre_pdf.startswith("A"):
                    tipo_pdf = "Auto"
                elif nombre_pdf.startswith("T"):
                    tipo_pdf = "Tutela"
                ano_publicacion = carpeta_ano
                fecha_modificacion = datetime.fromtimestamp(os.path.getmtime(ruta_pdf))

                # Creación del documento a insertar en MongoDB
                documento = {
                    "Providencia": nombre_pdf,
                    "Tipo": tipo_pdf,
                    "AnoPublicacion": ano_publicacion,
                    "Texto": texto_pdf,
                    "FechaPublicacion": fecha_modificacion
                }

                # Inserción del documento en la colección
                coleccion.insert_one(documento)

