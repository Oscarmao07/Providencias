# Aplicativo de Consulta de Providencias

Este aplicativo web permite realizar consultas a una base de datos de providencias. Permite buscar providencias por diferentes criterios, realizar conteos por tipo y año, y obtener un conteo general por año de publicación.

## Características

- Consulta por nombre de providencia: Permite buscar providencias por su nombre.
- Consulta por año de publicación: Permite buscar providencias por el año en que fueron publicadas.
- Consulta por tipo de providencia: Permite buscar providencias por su tipo Constitucionalidad, Auto o Tutela.
- Consulta por rango de fecha: Permite buscar providencias que se encuentren dentro de un rango de fechas.
- Consulta por texto: Permite buscar providencias que contengan un texto específico.
- Conteo por tipo y año: Permite obtener el conteo de providencias agrupadas por tipo y año.
- Conteo de providencias por todos los años publicados: Permite obtener el conteo total de providencias por cada año de publicación.

## Tecnologías utilizadas

- Python: lenguaje de programación utilizado para el desarrollo del backend.
- Flask: framework de Python utilizado para construir la aplicación web.
- MongoDB: base de datos utilizada para almacenar las providencias.
- HTML/CSS: lenguajes utilizados para el desarrollo del frontend.

## Configuración

1. Haber ejecutado la aplicación carguepdf.py
2. Instala las dependencias requeridas: `pip install -r requirements.txt`
3. Configura la conexión a la base de datos MongoDB:
MONGO_HOST = "localhost"  # Host de MongoDB
MONGO_PUERTO = "27017"  # Puerto de MongoDB
MONGO_TIMEOUT = 1000  # Tiempo de espera para la conexión en milisegundos
4. Ejecuta la aplicación: `python appweb.py`
5. Accede a la aplicación en tu navegador web: `http://localhost:5000`


## Autor

Oscar Mauricio Carvajal Suárez

