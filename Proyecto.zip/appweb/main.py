import pymongo
from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)

# Establecer la conexión a MongoDB
def establecer_conexion():
    MONGO_HOST = "localhost"
    MONGO_PUERTO = "27017"
    MONGO_TIMEOUT = 1000

    MONGO_URI = "mongodb://" + MONGO_HOST + ":" + MONGO_PUERTO + "/"

    try:
        cliente = pymongo.MongoClient(MONGO_URI, serverSelectionTimeoutMS=MONGO_TIMEOUT)
        cliente.server_info()
        print("Conexión a MongoDB exitosa")

        # Crear un índice de texto en el campo "Texto"
        coleccion = cliente["proyectoBDF"]["providenciasF"]
        coleccion.create_index([("Texto", pymongo.TEXT)])

        return cliente
    except pymongo.errors.ServerSelectionTimeoutError as errorTiempo:
        print("Tiempo excedido " + str(errorTiempo))
    except pymongo.errors.ConnectionFailure as errorConexion:
        print("Fallo al conectarse a MongoDB " + str(errorConexion))
    return None

# Consultar por el nombre de una providencia
def consultar_por_nombre(cliente, nombre_providencia):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    query = {"Providencia": nombre_providencia}
    resultados = coleccion.find(query)
    return list(resultados)

# Consultar por un año específico
def consultar_por_ano(cliente, ano_publicacion):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    query = {"AnoPublicacion": ano_publicacion}
    resultados = coleccion.find(query)
    return list(resultados)

# Consultar por tipo de providencia
def consultar_por_tipo(cliente, tipo_providencia):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    query = {"Tipo": tipo_providencia}
    resultados = coleccion.find(query)
    return list(resultados)

# Consultar las providencias por un rango de fecha específico
def consultar_por_rango_fecha(cliente, fecha_inicio, fecha_fin):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    query = {"FechaPublicacion": {"$gte": fecha_inicio, "$lte": fecha_fin}}
    resultados = coleccion.find(query)
    return list(resultados)


# Consultar una providencia por cualquier texto
def consultar_por_texto(cliente, texto):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    query = {"$text": {"$search": texto}}
    resultados = coleccion.find(query)
    return list(resultados)

# Conteo de providencias por todos los años publicados
def conteo_por_ano_publicacion(cliente):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    pipeline = [{"$group": {"_id": "$AnoPublicacion", "count": {"$sum": 1}}}]
    resultados = coleccion.aggregate(pipeline)
    return list(resultados)

# Conteo de providencias por tipo y año específico
def conteo_por_tipo_y_ano(cliente, tipo_providencia, ano_publicacion):
    db = cliente["proyectoBDF"]
    coleccion = db["providenciasF"]
    pipeline = [
        {"$match": {"Tipo": tipo_providencia, "AnoPublicacion": ano_publicacion}},
        {"$group": {"_id": "$Tipo", "count": {"$sum": 1}}}
    ]
    resultados = coleccion.aggregate(pipeline)
    return list(resultados)

# Rutas y funciones de manejo de solicitudes
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'tipo_ano' in request.form:
            tipo_providencia_input = request.form.get('tipo_providencia')
            ano_publicacion_input = request.form.get('ano_publicacion')
            cliente = establecer_conexion()
            resultados_tipo_ano = conteo_por_tipo_y_ano(cliente, tipo_providencia_input, ano_publicacion_input)
            conteo_ano_publicacion = conteo_por_ano_publicacion(cliente)
            return render_template('index.html', conteo_ano=conteo_ano_publicacion, resultados_tipo_ano=resultados_tipo_ano)
        else:
            if 'nombre_providencia' in request.form:
                nombre_providencia_input = request.form.get('nombre_providencia')
                cliente= establecer_conexion()
                resultados_nombre = consultar_por_nombre(cliente, nombre_providencia_input)
                return render_template('nombre.html', resultados=resultados_nombre)
            elif 'ano_publicacion' in request.form:
                ano_publicacion_input = request.form.get('ano_publicacion')
                cliente = establecer_conexion()
                resultados_ano = consultar_por_ano(cliente, ano_publicacion_input)
                return render_template('anio.html', resultados=resultados_ano)
            elif 'tipo_providencia' in request.form:
                tipo_providencia_input = request.form.get('tipo_providencia')
                cliente = establecer_conexion()
                resultados_tipo = consultar_por_tipo(cliente, tipo_providencia_input)
                return render_template('consultar_tipo.html', resultados=resultados_tipo)
            elif 'rango_fecha' in request.form:
                fecha_inicio_input = request.form.get('fecha_inicio')
                fecha_fin_input = request.form.get('fecha_fin')
                fecha_inicio = datetime.strptime(fecha_inicio_input, "%Y-%m-%d")
                fecha_fin = datetime.strptime(fecha_fin_input, "%Y-%m-%d")
                cliente = establecer_conexion()
                resultados_rango_fecha = consultar_por_rango_fecha(cliente, fecha_inicio, fecha_fin)
                return render_template('rango_fecha.html', resultados=resultados_rango_fecha)
            elif 'texto' in request.form:
                texto_input = request.form.get('texto')
                cliente = establecer_conexion()
                resultados_texto = consultar_por_texto(cliente, texto_input)
                return render_template('texto.html', resultados=resultados_texto)
    else:
        cliente = establecer_conexion()
        conteo_ano_publicacion = conteo_por_ano_publicacion(cliente)
        return render_template('index.html', conteo_ano=conteo_ano_publicacion)



app.debug = True

if __name__ == '__main__':
    app.run()
